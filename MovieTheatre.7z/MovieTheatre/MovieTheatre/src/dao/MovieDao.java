package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import utilty.DbTransaction;
import bean.MoviePojo;

public class MovieDao 
{
	public boolean add(MoviePojo m) throws SQLException
	{
		DbTransaction db = new DbTransaction("jdbc:oracle:thin:@172.25.192.82:1521:javaaodb","HJA41ORAUSER4D","tcshyd","TBL_MOVIE_1095118");
		String tbl = db.getTableName();
		Connection con = db.getConnection();
		String sql = "insert into " + tbl + " values(seq.nextval,?,?,?,?)";
		PreparedStatement stmt=con.prepareStatement(sql);  
		stmt.setString(1, m.getMovieName());
		stmt.setString(2, m.getMovieDirector());
		stmt.setInt(3, m.getDurtaion());
		stmt.setString(4, m.getScreen());
		 
		int flag=stmt.executeUpdate();
		
		if(flag==1)
			return true;
		else
			return false;
	}
	
	public ArrayList<MoviePojo> search() throws SQLException
	{
		ArrayList<MoviePojo> al=new ArrayList<MoviePojo>();
		DbTransaction db = new DbTransaction("jdbc:oracle:thin:@172.25.192.82:1521:javaaodb","HJA41ORAUSER4D","tcshyd","TBL_MOVIE_1095118");
		String tbl = db.getTableName();
		String s = "select * from " + tbl;
		Connection con=db.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(s);
        
		while (rs.next())
        {
           MoviePojo cd=new MoviePojo();
           
           cd.setMovieId(rs.getInt(1));
           cd.setMovieName(rs.getString(2));
           cd.setMovieDirector(rs.getString(3));
           cd.setDurtaion(rs.getInt(4));
           cd.setScreen(rs.getString(5));
           
           al.add(cd);
        }
		return al;
	}
}