package services;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.MovieDao;

import bean.MoviePojo;

public class MovieServices 
{
	public boolean addMovie(MoviePojo c) throws SQLException
	{
		MovieDao o = new MovieDao();
		boolean b = o.add(c);
		return b;
	}
		
	public ArrayList<MoviePojo> searchMovie() throws SQLException
	{
		ArrayList<MoviePojo> al = new ArrayList<MoviePojo>();
		MovieDao o = new MovieDao();
		al = o.search();
		return al;
	}
}