package utilty;

import java.sql.*;

public class DbTransaction
{
	private Connection connection;
	private String password;
	private String tableName;
	private String url;
	private String user;
	
	public DbTransaction(String url, String user, String password, String tableName)
	{
		this.url=url;
		this.user=user;
		this.password=password;
		this.setTableName(tableName);
	}
	
	public Connection getConnection()
	{
		try
		{
			closeConnection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(url,user,password);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		return connection;
	}
	
	public void closeConnection()
	{
		try
		{
			if(connection != null && connection.isClosed() == false)
				connection.close();
			connection = null;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public String getTableName()
	{
		return tableName;
	}
	
	public String getUrl()
	{
		return url;
	}
	
	public void setTableName(String tableName)
	{
		this.tableName = tableName;
	}
	
	public void setUrl(String url)
	{
		this.url = url;
	}
}